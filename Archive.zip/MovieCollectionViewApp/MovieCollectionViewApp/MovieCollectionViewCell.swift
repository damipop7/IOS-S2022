//
//  MovieCollectionViewCell.swift
//  MovieCollectionViewApp
//
//  Created by Student on 4/12/22.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageViewoutlet: UIImageView!
    
    func assignMovies(with movie: Movie){
        imageViewoutlet.image = movie.image
    }

}
