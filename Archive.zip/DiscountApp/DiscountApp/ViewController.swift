//
//  ViewController.swift
//  DiscountApp
//
//  Created by Student on 2/15/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
   
    @IBOutlet weak var AmountTextField: UITextField!
    
    
    @IBOutlet weak var DiscountTextField: UITextField!
    
    @IBAction func SubmitButton(_ sender: UIButton) {
        var amount = Double (AmountTextField.text!)
        var discount = Double (DiscountTextField.text!)
        
        var priceleft = amount! * (1 - discount! / 100)
        
        LastLabel.text = ("Price After Disocunt is  \(priceleft)")
        
        
        
    }
    
    @IBOutlet weak var LastLabel: UILabel!


}

