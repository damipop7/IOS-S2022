//
//  ResultViewController.swift
//  Popoola_DiceGame
//
//  Created by Student on 4/7/22.
//

import UIKit

class ResultViewController: UIViewController {
    var p1 = ""
    var p2 = ""
    var total1 = 0
    var total2 = 0
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        TotalGames1.text = "Total number of games \(p1) has won: 0"
        TotalGames2.text = "Total number of games \(p2) has won: 0"
    }
    
    
    @IBOutlet weak var TotalGames1: UILabel!
    @IBOutlet weak var TotalGames2: UILabel!
    @IBOutlet weak var ResultLabel1: UILabel!
    @IBOutlet weak var ResultLabel2: UILabel!
    @IBOutlet weak var ImageView: UIImageView!
    
    @IBAction func RollADice(_ sender: Any) {
        var rand1 = Int.random(in: 1...6)
        var rand2 = Int.random(in: 1...6)
        
        ResultLabel1.text = "\(p1) score is \(rand1)"
        ResultLabel2.text = "\(p2) score is \(rand2)"
        if (rand1 > rand2){
            total1 += 1
            TotalGames1.text = "Total number of games \(p1) has won: \(total1)"
            if (rand1 == 1){
                //ImageView.image = UIImage("dice1")
            }
        
        }
        else if (rand2 > rand1){
            total2 += 1
            TotalGames2.text = "Total number of games \(p2) has won: \(total2)"
        }
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
