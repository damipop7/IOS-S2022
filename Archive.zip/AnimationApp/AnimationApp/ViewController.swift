//
//  ViewController.swift
//  AnimationApp
//
//  Created by Student on 3/15/22.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var ImageOutlet: UIImageView!
    @IBOutlet weak var HappyBtnO: UIButton!
    @IBOutlet weak var SadBtnO: UIButton!
    @IBOutlet weak var AngryBtnO: UIButton!
    @IBOutlet weak var ShakeBtnO: UIButton!
    @IBOutlet weak var ShowBtn0: UIButton!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //Move all the components outside the view
        ImageOutlet.frame.origin.x = view.frame.maxX;
    }
    
    override func viewDidAppear(_ animated: Bool) {
        ImageOutlet.frame.origin.x = view.frame.maxX;
        HappyBtnO.frame.origin.x = view.frame.width;
        SadBtnO.frame.origin.x = view.frame.width;
        AngryBtnO.frame.origin.x = view.frame.width;
        ShakeBtnO.frame.origin.x = view.frame.width;
    }
    
    @IBAction func HappyBtn(_ sender: UIButton) {
        animateImage("happy")
    }
    @IBAction func SadBtn(_ sender: UIButton) {
        animateImage("sad")
    }
    @IBAction func AngryBtn(_ sender: UIButton) {
        animateImage("angry")
    }
    @IBAction func ShakeBtn(_ sender: UIButton) {
        //Rectangle r = new Rectangle (x, y, w, h)
        var w = ImageOutlet.frame.width
        w += 40
        var h = ImageOutlet.frame.height
        h += 40
        
        var x = ImageOutlet.frame.origin.x - 20
        var y = ImageOutlet.frame.origin.y - 20
        
        var largerFrame = CGRect(x: x, y: y, width: w, height: h)
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 0, animations: {
            self.ImageOutlet.frame = largerFrame
        })
    }
    
    @IBAction func ShowBtn(_ sender: UIButton) {
        UIView.animate(withDuration: 1, animations: {
            self.ImageOutlet.center.x = self.view.center.x;
            self.HappyBtnO.center.x = self.view.center.x;
            self.SadBtnO.center.x = self.view.center.x;
            self.AngryBtnO.center.x = self.view.center.x;
            self.ShakeBtnO.center.x = self.view.center.x;
            self.ShowBtn0.isEnabled = false
        })
    
    }//end ShowBtn
    
    func animateImage(_ imageName: String){
        
        //Image as opaque
        UIView.animate(withDuration: 1, animations: {self.ImageOutlet.alpha = 0;
        })
        
        
        UIView.animate(withDuration: 1, delay: 0.2, animations: {
            self.ImageOutlet.alpha = 1 //image transparent
            self.ImageOutlet.image = UIImage(named: imageName)
        })
        ImageOutlet.image = UIImage(named: imageName)
    }
    
    
    
}

