//
//  ViewController.swift
//  CourseDisplayApp
//
//  Created by Student on 2/10/22.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var ImageViewOutlet: UIImageView!
    
    @IBOutlet weak var CrsNum: UILabel!
    
    @IBOutlet weak var CrsTitle: UILabel!
    
    @IBOutlet weak var CrsSemester: UILabel!
    
    @IBOutlet weak var PreviousButton: UIButton!
    
    @IBOutlet weak var NextButton: UIButton!
    
    let courses = [
                    ["img01", "44565", "Network Security", "Fall 2022"],
                   ["img02", "44643", "IOS", "Spring 2022"],
                   ["img03", "44656", "Streaming Data", "Summer 2022",]
                    ]
    
    var imageNumber  = 0
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        //Load the details (image, num, title, and sum) of the first (Oth element) course
        
        updateUI(imageNumber);
        
        //Previous button is disabled
        PreviousButton.isEnabled = false;
        
    }

    @IBAction func PreviousButtonClicked(_ sender: Any) {
        //next button should be enabled
        NextButton.isEnabled = true
        
        //update the UI
        imageNumber -= 1
        updateUI(imageNumber)
        
        //if the course is at the 0th position, the previous button is disabled
        if (imageNumber == 0)
        {
            PreviousButton.isEnabled = false
        }
    }
    
    @IBAction func NextButtonClicked(_ sender: Any) {
        //When the next button is clicked, the UI should be updated with the next course details
        imageNumber += 1
        updateUI(imageNumber)
        
        //PREVIOUS BUTTON SHOULD BE ENABLED
        PreviousButton.isEnabled = true
        
        //Once at the end of the array next button should be disabled
        if (imageNumber == courses.count-1)
        {
            NextButton.isEnabled = false
        }
        
    }
    
    func updateUI(_ imageNumber : Int){
        ImageViewOutlet.image = UIImage(named: courses[imageNumber][0])
        CrsNum.text = courses[imageNumber][1]
        CrsTitle.text = courses[imageNumber][2]
        CrsSemester.text = courses[imageNumber][3]
    }
    
}

