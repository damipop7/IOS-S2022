//
//  ViewController.swift
//  StudentApp
//
//  Created by Student on 3/24/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    
    }

    @IBOutlet weak var SIdOutlet: UITextField!
    
    var studentsArray = students

    @IBAction func LoginButtonAction(_ sender: Any)
    {
        var enteredID = SIdOutlet.text!
        
        //Loop the array to find the student
        for student in studentsArray
        {
            if enteredID == student.sid
            {
                //student found and store the student in a global variable.
                studentFound = student
                //boolean flag as true,since we found a student.
                isStudent = true
            }
        }
    }
 
    
    
}

