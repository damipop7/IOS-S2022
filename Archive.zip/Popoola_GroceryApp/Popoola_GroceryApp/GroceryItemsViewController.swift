//
//  GroceryItemsViewController.swift
//  Popoola_GroceryApp
//
//  Created by Student on 4/7/22.
//

import UIKit

class GroceryItemsViewController: UIViewController, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return items.count
    }
    
    var items : [GroceryItem] = []

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //return the cell with the data.
        let cellb =
            groceryItemsTableView.dequeueReusableCell(withIdentifier: "itemCell", for: indexPath)
        
        //Assign the data to the cell.
        cellb.textLabel?.text = items[indexPath.row].itemName
            
        //return the cell
        return cellb
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        groceryItemsTableView.dataSource = self
        self.title = "Grocery Items"
    }
    
    @IBOutlet weak var groceryItemsTableView: UITableView!
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "itemInfoSegue"{
            let destination = segue.destination as! ItemInfoViewController
            destination.info = items[(groceryItemsTableView.indexPathForSelectedRow?.row)!]
        }
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
