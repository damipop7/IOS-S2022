//
//  ViewController.swift
//  Popoola_GroceryApp
//
//  Created by Student on 4/7/22.
//

import UIKit

class GrocerySectionViewController: UIViewController, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return grocerySections.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //return the cell with the data.
        let cell = grocerySectionTableViews.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        
        //assign movies to cell
        cell.textLabel?.text = grocerySections[indexPath.row].section
        
        //return cell
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        self.title = "Grocery Section"
        grocerySectionTableViews.dataSource = self
        print(grocerySections)
        
    }
    
    @IBOutlet weak var grocerySectionTableViews: UITableView!
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "itemsSegue"{
            //Create a destination of type GroceryItemsViewController
            let destination = segue.destination as! GroceryItemsViewController
            
            destination.items = grocerySections[(grocerySectionTableViews.indexPathForSelectedRow?.row)!].items_Array
        }
    }

}

