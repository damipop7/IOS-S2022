//
//  MovieData.swift
//  Popoola_Movies
//
//  Created by Student on 4/25/22.
//

import Foundation
import UIKit

struct Movie {
    var title : String
    var image : String
    var releasedYear : String
    var movieRating : String
    var boxOffice : String
    var moviePlot : String
    var cast : [String]
}

struct Genre {
    var category : String
    var movies : [Movie]
}

let Details1 =  Genre(category: "Sci-Fi", movies:
                        [Movie (title: "Avengers: End game", image:  "avenger", releasedYear: "2019", movieRating: "8.1" , boxOffice: "$2.798B", moviePlot: "In 2023, Scott Lang escapes from the Quantum Realm leading to a string of events that ends up with the avengers beating a 2014 version of Thanos", cast: ["Downey, Evans, Hemsworth, Pratt"]),
                         Movie (title: "Avatar", image: "AVATAR", releasedYear: "2009", movieRating: "7.8", boxOffice: "2.847 billion USD", moviePlot: "On the lush alien world of Pandora live the Na'vi, beings who appear primitive but are highly evolved. Because the planet's environment is poisonous, human/Na'vi hybrids, called Avatars, must link to human minds to allow for free movement on Pandora. Jake Sully (Sam Worthington), a paralyzed former Marine, becomes mobile again through one such Avatar and falls in love with a Na'vi woman (Zoe Saldana). As a bond with her grows, he is drawn into a battle for the survival of her world.", cast: [" Sam Worthington, Zoe Saldana, Stephen Lang, Michelle Rodriguez, and Sigourney Weaver."]),
                         Movie (title: "Mad Max", image: "mad max", releasedYear: "2015", movieRating: "8.1", boxOffice: "$475 million", moviePlot: "Taking place in a dystopian Australia in the near future, Mad Max tells the story of a highway patrolman cruising the squalid back roads that have become the breeding ground of criminals foraging for gasoline and scraps.", cast: ["Tom Hardy · Max Rockatansky ; Charlize Theron · Imperator Furiosa ; Nicholas Hoult · Nux ; Zoë Kravitz · Toast the Knowing ; Hugh Keays-Byrne ·"]),
                         Movie (title: "Furious 7", image: "f7", releasedYear: "2015", movieRating: "7.1", boxOffice: "$1.516 billion", moviePlot: "After defeating international terrorist Owen Shaw, Dominic Toretto (Vin Diesel), Brian O'Conner (Paul Walker) and the rest of the crew have separated to return to more normal lives. However, Deckard Shaw (Jason Statham), Owen's older brother, is thirsty for revenge. A slick government agent offers to help Dom and company take care of Shaw in exchange for their help in rescuing a kidnapped computer hacker who has developed a powerful surveillance program.", cast: ["Vin Diesel · Dominic Toretto ; Paul Walker · Brian O'Conner ; Dwayne Johnson · Hobbs ; Jason Statham · Deckard Shaw ; Michelle Rodriguez"]),
                        ])
let Details2 =  Genre(category: "Romance", movies:
                        [Movie (title: "The Photograph", image: "photograph-1", releasedYear: "2020", movieRating: "7.2", boxOffice: "$20.7 million", moviePlot: "When famed photographer Christina Eames dies unexpectedly, she leaves her estranged daughter, Mae, hurt, angry and full of questions. When Mae finds a photograph tucked away in a safe-deposit box, she soon finds herself delving into her mother's early life -- an investigation that leads to an unexpected romance with a rising journalist.", cast: ["Issa Rae; Lakeith Stanfield; Lil Rel Howery; Rob Morgan; Courtney B. Vance"]),
                         Movie (title: "Titanic", image: "titanic", releasedYear: "1997", movieRating: "7.9", boxOffice: "$2.202 billion", moviePlot: "James Cameron's Titanic is an epic, action-packed romance set against the ill-fated maiden voyage of the R.M.S. Titanic; the pride and joy of the White Star Line and, at the time, the largest moving object ever built. She was the most luxurious liner of her era -- the ship of dreams -- which ultimately carried over 1,500 people to their death in the ice cold waters of the North Atlantic in the early hours of April 15, 1912.", cast: ["Leonardo DiCaprio · Jack Dawsonas Jack Dawson ; Kate Winslet · Rose Dewitt Bukateras Rose Dewitt Bukater ; Billy Zane · Cal Hockleyas Cal Hockley"]),
                         Movie (title: "The wolf of Wall Street", image: "the wolf of wall street", releasedYear: "2013", movieRating: "8.2", boxOffice: "$392 million", moviePlot: "In 1987, Jordan Belfort (Leonardo DiCaprio) takes an entry-level job at a Wall Street brokerage firm. By the early 1990s, while still in his 20s, Belfort founds his own firm, Stratton Oakmont. Together with his trusted lieutenant (Jonah Hill) and a merry band of brokers, Belfort makes a huge fortune by defrauding wealthy investors out of millions. However, while Belfort and his cronies partake in a hedonistic brew of sex, drugs and thrills, the SEC and the FBI close in on his empire of excess.", cast: ["Leonardo DiCaprio · Jordan Belfort ; Jonah Hill · Donnie Azoff ; Margot Robbie · Naomi Lapaglia ; Matthew McConaughey · Mark Hanna ; Kyle Chandler "]),
                         Movie (title: "Beauty and the Beast", image: "bb", releasedYear: "2017", movieRating: "7.1" , boxOffice:"1.264 billion USD", moviePlot: "An arrogant prince is cursed to live as a terrifying beast until he finds true love. Strangely, his chance comes when he captures an unwary clockmaker, whose place is then taken by his bold and beautiful daughter Belle. Helped by the Beast's similarly enchanted servants, including a clock, a teapot and a candelabra, Belle begins to see the sensitive soul behind the fearsome facade. But as time runs out, it soon becomes obvious that Belle's cocky suitor Gaston is the real beast of the piece.", cast: ["Robby Benson · Jesse Corti · Rex Everhart · Angela Lansbury · Paige O'Hara · Jerry Orbach · Bradley Pierce · David Ogden Stiers"])
                        ])
let Details3 =  Genre(category: "Adventure", movies:
                        [Movie (title: "Conan the Destroyer", image: "Conan", releasedYear: "1984", movieRating: "5.9", boxOffice: "18 million USD", moviePlot: "In his second cinematic adventure, the mighty warrior Conan (Arnold Schwarzenegger) is tricked into working for the scheming Queen Taramis (Sarah Douglas). Along with finding a mystical horn, Conan and his allies, which include the fierce fighter, Zula (Grace Jones), and the wisecracking sorcerer, Akiro (Mako), must protect the beautiful young Princess Jehnna (Olivia d'Abo). With deception and danger at every turn, Conan has to use all of his power to defeat the evil foes that stand in his way.", cast: [" Arnold Schwarzenegger · Grace Jones · Wilt Chamberlain · Mako · Tracey Walter · Sarah Douglas · Olivia d'Abo · Pat Roach."]),
                        Movie (title: "The dark Knight", image: "the dark knight", releasedYear: "2008", movieRating: "9", boxOffice: "1.005 B", moviePlot: "With the help of allies Lt. Jim Gordon (Gary Oldman) and DA Harvey Dent (Aaron Eckhart), Batman (Christian Bale) has been able to keep a tight lid on crime in Gotham City. But when a vile young criminal calling himself the Joker (Heath Ledger) suddenly throws the town into chaos, the caped Crusader begins to tread a fine line between heroism and vigilantism.", cast: ["Christian Bale · Bruce Wayne ; Heath Ledger · Joker ; Aaron Eckhart · Harvey Dent ; Michael Caine · Alfred ; Maggie Gyllenhaal · "]),
                        Movie (title: "Spiderman: No Way Home", image: "spiderman NWH", releasedYear: "2022", movieRating: "8.4", boxOffice: "1.892 billion USD", moviePlot: "With Spider-Man's identity now revealed, our friendly neighborhood web-slinger is unmasked and no longer able to separate his normal life as Peter Parker from the high stakes of being a superhero. When Peter asks for help from Doctor Strange, the stakes become even more dangerous, forcing him to discover what it truly means to be Spider-Man.", cast: ["Tom Holland · Peter Parker ; Zendaya · MJ ; Benedict Cumberbatch · Doctor Strange ; Jacob Batalon · Ned Leeds ; Jon Favreau · Happy Hogan"]),
                         Movie (title: "Pirates of the Caribbean: Dead Men Tell No Tales", image: "dt", releasedYear: "2017", movieRating: "6.5", boxOffice: "794.9 million USD", moviePlot: "Thrust into an all-new adventure, a down-on-his-luck Capt. Jack Sparrow feels the winds of ill-fortune blowing even more strongly when deadly ghost sailors led by his old nemesis, the evil Capt. Salazar, escape from the Devil's Triangle. Jack's only hope of survival lies in seeking out the legendary Trident of Poseidon, but to find it, he must forge an uneasy alliance with a brilliant and beautiful astronomer and a headstrong young man in the British navy.", cast: ["Johnny Depp, Javier Bardem, Geoffrey Rush, Brenton Thwaites, Kaya Scodelario, and Kevin McNally."])
                        ])

let movie_list = [Details1, Details2, Details3]
