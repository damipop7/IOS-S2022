//
//  MovieCollectionViewCell.swift
//  Popoola_Movies
//
//  Created by Student on 4/28/22.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var movieImage: UIImageView!
    
    func assignMovies(with movie: Movie){
        movieImage.image = UIImage(named: movie.image)
        print(movie)
    }
}
