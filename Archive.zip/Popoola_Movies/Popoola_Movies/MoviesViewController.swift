//
//  MoviesViewController.swift
//  Popoola_Movies
//
//  Created by Student on 4/25/22.
//

import UIKit

class MoviesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return details.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        var cell = movieCollectionView.dequeueReusableCell(withReuseIdentifier: "movieCell", for: indexPath) as! MovieCollectionViewCell
        //assign movies to cell
        cell.assignMovies(with: details[indexPath.row])
                                                           
        //return cell
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
       movieNameLabel.text = "Movie Title: \(details[indexPath.row].title)"
        movieYearLabel.text = "Year released: \(details[indexPath.row].releasedYear)"
        movieRatingLabel.text = "Movie rating: \(details[indexPath.row].movieRating)"
        movieBoxOfficeLabel.text = "Revenue: \(details[indexPath.row].boxOffice)"
        moviePlotLabel.text = "Plot: \(details[indexPath.row].moviePlot)"
        movieCastLabel.text = "Revenue: \(details[indexPath.row].cast)"
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        movieCollectionView.dataSource = self
        movieCollectionView.delegate = self
    }
    var details : [Movie] = []
    
    @IBOutlet weak var movieCollectionView: UICollectionView!
    @IBOutlet weak var movieNameLabel: UILabel!
    @IBOutlet weak var movieRatingLabel: UILabel!
    @IBOutlet weak var movieBoxOfficeLabel: UILabel!
    @IBOutlet weak var movieYearLabel: UILabel!
    @IBOutlet weak var moviePlotLabel: UILabel!
    @IBOutlet weak var movieCastLabel: UILabel!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
