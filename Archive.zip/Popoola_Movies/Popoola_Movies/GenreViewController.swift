//
//  ViewController.swift
//  Popoola_Movies
//
//  Created by Student on 4/25/22.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movie_list.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //return the cell with the data.
        let cell = genreTableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        
        //assign movies to cell
        cell.textLabel?.text = movie_list[indexPath.row].category
        
        //return cell
        return cell
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        genreTableView.dataSource = self
    }
    @IBOutlet weak var genreTableView: UITableView!
   
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "movieSegue"{
            //Create a destination of type GroceryItemsViewController
            let destination = segue.destination as! MoviesViewController
            
            destination.details = movie_list[(genreTableView.indexPathForSelectedRow?.row)!].movies
        }
    }
    
}


