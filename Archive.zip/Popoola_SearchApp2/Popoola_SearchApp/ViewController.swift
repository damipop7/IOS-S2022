//
//  ViewController.swift
//  Popoola_SearchApp
//
//  Created by Student on 2/25/22.
//

import UIKit

class ViewController: UIViewController {

    var topic = 0
    var sec_arr = 0
    var arr1 = [
        ["lion", "horse", "whale", "hawk", "SiberianHusky"],
        ["idris_elba", "Jason_Mamoa", "Zendaya", "issa", "Chadwick"],
        ["Batman", "Thor", "Spider-Man", "wolverine", "black-panther"]]
    var animal_keyword = ["animal", "living", "ocean" ,"birds", "dog"]
    var actors_keyword = ["actor", "movie", "film", "series", "season"]
    var superheroes_keyword = ["hero", "Marvel", "DC", "X-men", "Leader"]
    var topics_array = [
        ["This is one of the result for animals", "There are many Beautiful animals in our world", "Here are some of my Favourite animals", "Some animals can fly", "This is a type of dog" ],
         ["This is one of the results for actors", "Hollywood spends Billions of dollars a year on movies", " These are some of my favorite Hollywood Actors", "Issa is an actress and producer", "Chadwick is late unfortunately"],
          ["Superheroes are all fictional", "These are some of my favorite heroes", "Spiderman is very popular", "wolverine has claws", "Black panther is a king"]]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        PreviousBtn.isHidden = false;
        NextBtn.isHidden = false;
        PreviousBtn.isEnabled = false;
        NextBtn.isEnabled = true;
        SearchBtn.isEnabled = true;
        ResetBtn.isHidden = false;
    }
    @IBOutlet weak var ResultImage: UIImageView!
    @IBOutlet weak var PreviousBtn: UIButton!
    @IBOutlet weak var NextBtn: UIButton!
    @IBOutlet weak var topicInfoText: UITextView!
    @IBOutlet weak var SearchTextField: UITextField!
    @IBOutlet weak var SearchBtn: UIButton!
    @IBOutlet weak var ResetBtn: UIButton!

    @IBAction func SearchButtonAction(_ sender: Any)
    {
        let input = SearchTextField.text!
        if (input != "")
        {
            SearchBtn.isEnabled = true;
        }
        if (animal_keyword.contains(input))
        {
            topic = 1
            topicInfoText.text! = topics_array[0][0]
            ResultImage.image = UIImage(named: arr1[0][0])
        }
        else if (actors_keyword.contains(input))
        {
            topic = 2
            topicInfoText.text! = topics_array[1][0]
            ResultImage.image = UIImage(named: arr1[1][0])
        }
        else if (superheroes_keyword.contains(input))
        {
            topic = 3
            topicInfoText.text! = topics_array[2][0]
            ResultImage.image = UIImage(named: arr1[2][0])
        }
        else
        {
            ResultImage.image  = UIImage(named: "searchnotfound")
        }
    }
   
    @IBAction func showpreviousImageBtn(_ sender: Any)
    {
        sec_arr -= 1
        let input = SearchTextField.text!
        if (topic == 1)
        {
            ResultImage.image = UIImage(named: arr1[0][sec_arr])
            topicInfoText.text! = topics_array[0][sec_arr]
        }
        else if (topic == 2)
        {
            ResultImage.image = UIImage(named: arr1[1][sec_arr])
            topicInfoText.text! = topics_array[1][sec_arr]
        }
        else if (topic == 3)
        {
            ResultImage.image = UIImage(named: arr1[2][sec_arr])
            topicInfoText.text! = topics_array[2][sec_arr]
        }
        if (topic == 0)
        {
            PreviousBtn.isEnabled = false;
        }
        NextBtn.isEnabled = false;
    }
    
    @IBAction func showNextImageBtn(_ sender: UIButton)
    {
        PreviousBtn.isEnabled = true;
        SearchBtn.isEnabled = false;
        sec_arr += 1
        var input = SearchTextField.text!
        if (animal_keyword.contains(input))
        {
            ResultImage.image = UIImage(named: arr1[0][sec_arr])
            topicInfoText.text! = topics_array[0][sec_arr]
        }
        else if (actors_keyword.contains(input))
        {
            ResultImage.image = UIImage(named: arr1[1][sec_arr])
            topicInfoText.text! = topics_array[1][sec_arr]
        }
        else if (superheroes_keyword.contains(input))
        {
            ResultImage.image = UIImage(named: arr1[2][sec_arr])
            topicInfoText.text! = topics_array[2][sec_arr]
        }
        if (sec_arr == 4)
        {
            NextBtn.isEnabled = false;
        }
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        SearchTextField.text! = ""
        topicInfoText.text = ""
        ResultImage.image = UIImage(named: "inactive")
        PreviousBtn.accessibilityElementsHidden = true;
        sec_arr = 0
        topic = 0
        PreviousBtn.isHidden = true;
        NextBtn.isHidden = true;
        SearchBtn.isEnabled = false;
        ResetBtn.isHidden = true;
    }
}

