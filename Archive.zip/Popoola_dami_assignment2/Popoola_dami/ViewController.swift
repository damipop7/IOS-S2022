//
//  ViewController.swift
//  Popoola_dami
//
//  Created by Student on 2/1/22.
//

import UIKit

class ViewController: UIViewController {
    
   
    @IBOutlet weak var firstNameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBOutlet weak var fullNameLabel: UILabel!
    
    @IBOutlet weak var initialsLabel: UILabel!
    
    @IBAction func onClickOfSubmit(_ sender: Any) {
        //To print the fullname in the fullname label and initials in the initials label
        let lname : String = lastNameTextField.text!
        let fname : String = firstNameTextField.text!
        var fullName = "Full Name: \(lname), \(fname)"
        fullNameLabel.text! = fullName
        
        var initial = "Initials: \(lname.first!)\( fname.first!)"
        initialsLabel.text! = initial
    }
    
    @IBAction func onClickOfReset(_ sender: Any) {
        //clear all the values inputed
        firstNameTextField.text! = " "
        lastNameTextField.text! = " "
        fullNameLabel.text! = " "
        initialsLabel.text! = " "
//
        let position = firstNameTextField.becomeFirstResponder()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

