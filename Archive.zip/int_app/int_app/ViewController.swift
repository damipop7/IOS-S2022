//
//  ViewController.swift
//  int_app
//
//  Created by Student on 2/8/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var InputtextField: UITextField!
    
    @IBAction func SubmitButton(_ sender: Any) {
        let input = Int (InputtextField.text!)
        if (input! % 2 == 0)
        {
            OutputLabel.text = ("\(input!) is an even number ")
        }
        else
        {
            OutputLabel.text = ("\(input!) is an odd number ")
        }

    }
    
    weak var OutputLabel: UILabel!

}
