//
//  ViewController.swift
//  Popoola_SearchApp
//
//  Created by Student on 2/25/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    @IBOutlet weak var SearchTextField: UITextField!
    
    @IBAction func SearchButtonAction(_ sender: Any) {
    }
    
    @IBOutlet weak var ResultImage: UIImageView!
    
    @IBAction func showpreviousImageBtn(_ sender: UIButton) {
    }
    
    @IBAction func showNextImageBtn(_ sender: UIButton) {
    }
    
    @IBOutlet weak var topicInfoText: UITextView!
}

