//
//  ViewController.swift
//  Popoola_ContactList
//
//  Created by Student on 4/26/22.
//

import UIKit

class ContactListViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contacts.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        //return the cell with the data.)
        let cell = ContactsTableView.dequeueReusableCell(withIdentifier: "ContactCell", for: indexPath)
        
        //assign movies to cell
        cell.textLabel?.text = contacts[indexPath.row][0]
        
        //return cell
        return cell
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        ContactsTableView.dataSource = self
        ContactsTableView.delegate = self
    }

    @IBOutlet weak var ContactsTableView: UITableView!
    
    @IBAction func ContactBtn(_ sender: Any) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "TableSegue"{
            //Create a destination of type GroceryItemsViewController
            let destination = segue.destination as! ContactDetailViewController
            
            destination.contact = contacts[(ContactsTableView.indexPathForSelectedRow?.row)!][0]
            destination.number = contacts[(ContactsTableView.indexPathForSelectedRow?.row)!][1]
        }
    }
    
    
    
}

