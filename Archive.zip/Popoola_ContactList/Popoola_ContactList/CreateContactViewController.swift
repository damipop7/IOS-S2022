//
//  CreateContactViewController.swift
//  Popoola_ContactList
//
//  Created by Student on 4/26/22.
//

import UIKit

class CreateContactViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    @IBOutlet weak var NewNum: UITextField!
    @IBOutlet weak var NewName: UITextField!
    
    @IBAction func NewContactBtn(_ sender: Any) {
        var ar = [NewName.text!,NewNum.text!]
        contacts.append(ar)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
