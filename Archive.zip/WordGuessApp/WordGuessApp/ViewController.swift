//
//  ViewController.swift
//  WordGuessApp
//
//  Created by Student on 2/22/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func InputTextField(_ sender: UITextField) {
        /*if ( == )
         {
            ou
         }*/
    }

    @IBOutlet weak var OutletLabel: UILabel!
    
    
}

