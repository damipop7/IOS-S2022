//
//  DetailsViewController.swift
//  TableViewDemo
//
//  Created by Student on 3/29/22.
//

import UIKit

class DetailsViewController: UIViewController {

    @IBOutlet weak var DisplayOutlet: UILabel!
    
    var product : Product?
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        DisplayOutlet.text = "The product \((product?.ProductName)!) is of \((product?.ProductCategory)!) category"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
