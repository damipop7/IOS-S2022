//
//  ViewController.swift
//  Popoola_WordGuessApp
//
//  Created by Student on 3/22/22.
//

import UIKit
import Foundation

class ViewController: UIViewController {

    var arr = [
        ["Swift", "Programming Language"],
        ["Iphone", "Apple" ],
        ["Simba","Lion King"],
        ["Dog", "animal"],
        ["Zendaya", "Actress"],
            ]
    
    var count = 0;
    var word = ""
    var lettersGuessed = ""
    var wg = 0
    var wr = 5
    var wm = 0
    let maxNumofWrongGuesses = 10
    
    
    @IBOutlet weak var WordGuessed: UILabel!
    
    @IBOutlet weak var wordsMissed: UILabel!
    
    @IBOutlet weak var WordsRemaining: UILabel!
    
    @IBOutlet weak var TotalWords: UILabel!
    
    @IBOutlet weak var UserGuessLabel: UILabel!
    
    @IBOutlet weak var GuessLetterField: UITextField!
    
    @IBOutlet weak var GuessLetterButton: UIButton!
    
    @IBOutlet weak var StatusLabel: UILabel!
    
    @IBOutlet weak var HintLabel: UILabel!
    
    @IBOutlet weak var PlayAgain: UIButton!
    
    func updateUnderscores(){
        for letter in word{
            UserGuessLabel.text! += "- "
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        PlayAgain.isHidden = true
        //GuessLetterField.isEnabled = false;
        
        //Get the first word from the array
        word = arr[count][0]
        
        UserGuessLabel.text = ""
        
        updateUnderscores();
        
        //Get the first hint from the array
        HintLabel.text = "Hint: " + arr[count][1]
        
        //Clear the status label intially.
        StatusLabel.text = ""
        var word_count = word.count
        TotalWords.text! = "Total number of words in game: " + String(wr)
        WordsRemaining.text = "Total number of letters in the word: " + (String(word_count))
        
    }
    
    @IBAction func GuessLetterButtonPressed(_ sender: Any) {
        var letter = GuessLetterField.text!
        wg += 1
        StatusLabel.text = "You have made \(wg) guess"
        
        //Replace the guessed letter if the letter is part of the word.
        lettersGuessed = lettersGuessed + letter
        var revealedWord = ""
        let tempWord = word.uppercased()
        for l in tempWord
        {
            if lettersGuessed.contains(l){
                revealedWord += "\(l)"
            }
            else{
                revealedWord += "_ "
                wm += (1/3)
            }
        }
        wordsMissed.text = "Total number of words guessed wrongly: \(round(Double(wm)))"
        if wm == maxNumofWrongGuesses{
            StatusLabel.text = "You are out of guesses.Try Again"
            GuessLetterButton.isEnabled = false
        }
        
        //Assigning the word to displaylabel after a guess
        UserGuessLabel.text = revealedWord
        GuessLetterField.text = ""
        
        //If the word is guessed correctly, we are enabling play again button and disabling the check button.
        if UserGuessLabel.text!.contains("_") == false
        {
            PlayAgain.isHidden = false;
            GuessLetterButton.isEnabled = false;
            WordGuessed.text = "Total number of words guessed successfully: " + String(wg+1)
        }
        GuessLetterButton.isEnabled = false
        
    }
    
    @IBAction func PlayAgainButtonPressed(_ sender: Any)
    {
        //Reset the button to disable initially.
        PlayAgain.isHidden = true
        
        //clear the label
        lettersGuessed = ""
        count += 1
        wg = 0

        var word_count = (word.count)
        WordsRemaining.text = "Total number of letters in the word: " + String(arr[count][0].count)
        TotalWords.text = "Total number of words in game: " + String(wr-1)
        WordGuessed.text = "Total number of words guessed successfully: \(count)"
        wordsMissed.text = "Total number of words guessed wrongly: \(wg) "
        StatusLabel.text = "You have made \(wg) guesses"
        
        //if count reaches the end of the array (all the words are guessed sucessfully), then print Congratualtions in the status label.
        if count == arr.count{
            StatusLabel.text = "Congratulations! You are done with the game, Please start again!"
            
            //clearing the labels.
            UserGuessLabel.text = ""
            HintLabel.text = ""
        }
        else{
            //fetch the next word from the array
            word = arr[count][0]
            
            //fetch the hint related to the word
            HintLabel.text = "Hint: "
            HintLabel.text! += arr[count][1]
            
            //Enabling the check button.
            GuessLetterButton.isEnabled = true
            
            UserGuessLabel.text = ""
            updateUnderscores()
        }
    }
    
    @IBAction func GuessLetterBox(_ sender: Any) {
        //Read the data from the text field
        var textEntered = GuessLetterField.text!;
        
        //Consider only the last character by calling textEntered.last and trimming the white spaces.
        textEntered = String(textEntered.last ?? " ").trimmingCharacters(in: .whitespaces)
        GuessLetterField.text = textEntered
        
        //Check whether the entered text is empty or not to enable check button.
        if textEntered.isEmpty{
            GuessLetterButton.isEnabled = false
        }
        else{
            GuessLetterButton.isEnabled = true
        }
    }
    
}

