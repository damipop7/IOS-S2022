//
//  ViewController.swift
//  Popoola_DiceGame
//
//  Created by Student on 2/24/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var Player1: UITextField!
    
    @IBOutlet weak var Player2: UITextField!
    
    @IBOutlet weak var Winner: UITextField!
    
    @IBOutlet weak var Player1Score: UITextField!
    
    @IBOutlet weak var Player2Score: UITextField!
    
    @IBAction func SubmitButton(_ sender: UIButton) {
        var name1 = Player1.text!
        var name2 = Player2.text!
        
        var dice1 = Int.random(in: 1...6)
        var dice2 = Int.random(in: 1...6)
     
        Player1Score.text! = ("\(name1)'s roll is \(dice1)")
        Player2Score.text! = ("\(name2)'s roll is \(dice2)")
        
        if (dice1>dice2)
        {
            Winner.text! = ("\(name1) won the game")
        }
        if (dice2>dice1)
        {
            Winner.text! = ("\(name2) won the game")
        }
        if (dice1 == dice2)
        {
            Winner.text! = ("The game is tie!")
        }
    }
    

    
    
    
    
    
}

