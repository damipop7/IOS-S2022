//
//  ViewController.swift
//  Popoola_calculator
//
//  Created by Student on 2/8/22.
//

import UIKit

class ViewController: UIViewController
{
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBOutlet weak var OutputLabel: UILabel!
 
    var Firstv = ""
    var Op = ""
    var Secondv = ""
    var Output = ""
    var Secondx = false
    var Firstx = false
    func addToFirstv(value: String)
    {
        Firstv = Firstv + value
        OutputLabel.text! = Firstv
    }
    func addToSecondv(value: String)
    {
        Secondv = Secondv + value
        OutputLabel.text! = Secondv
    }
    func clearAll()
    {
        Firstv = ""
        Secondv = ""
        Op = ""
        OutputLabel.text = ""
        Secondx = false
    }
    
    @IBAction func buttonAC(_ sender: UIButton) {
        clearAll()
    }
    @IBAction func buttonC(_ sender: UIButton) {
        if (Secondx == false)
        {
            Firstv = ""
        }
        else
        {
            Secondv = ""
        }
        OutputLabel.text! = ""
    }
    @IBAction func buttonN(_ sender: UIButton) {
        if (Firstv.first == "-")
        {
            Firstv.removeFirst()
            OutputLabel.text! = Firstv
        }
        else
        {
            OutputLabel.text! = "-"
            Firstv = "-\(Firstv)"
            OutputLabel.text! = Firstv
        }
    }
    @IBAction func buttonDecp(_ sender: UIButton) {
        addToFirstv(value: ".")
        //Firstv = "\(Firstv)."
        //OutputLabel.text! = Firstv
        
        if (Secondx == true)
        {
            Secondv = "\(Secondv)."
            OutputLabel.text! = Secondv
        }
    }
    @IBAction func percentTap(_ sender: UIButton) {
        Op = "%"
        OutputLabel.text! = ""
        Secondx = true
    }
    @IBAction func AddButton(_ sender: UIButton) {
        Op = "+"
        OutputLabel.text! = ""
        Secondx = true
    }
    @IBAction func MultiplyButton(_ sender: UIButton) {
        Op = "*"
        OutputLabel.text! = ""
        Secondx = true
    }
    @IBAction func SubtractB(_ sender: UIButton) {
        Op = "-"
        OutputLabel.text! = ""
        Secondx = true
    }
    @IBAction func dvsnButton(_ sender: UIButton) {
        Op = "/"
        OutputLabel.text! = ""
        Secondx = true
    }
    
    @IBAction func EqualsB(_ sender: UIButton) {
        OutputLabel.text! = ""
        if (Op == "%" )
        {
            if (Firstv.last == ".")
            {
                Firstv.removeLast()
            }
            var x = (Double(Firstv)!.truncatingRemainder(dividingBy: Double(Secondv)!))
            OutputLabel.text! = String(round(x * 10) / 10)
        }
        else if (Op == "+" )
        {
            if (Firstv.last == ".")
            {
                Firstv.removeLast()
            }
            let a = Float(Firstv)!
            let b = Float(Secondv)!
            var res = (a + b)
            OutputLabel.text! = String(res)
        }
        if (Op == "*" )
        {
            OutputLabel.text! = String (Double (Firstv)! * Double (Secondv)!)
        }
        if (Op == "-" )
        {
            OutputLabel.text! = String (Double (Firstv)! - Double (Secondv)!)
        }
        if (Op == "/" )
        {
            let fullv = String (Double (Firstv)! / Double (Secondv)!)
            let value = Float(fullv)
            let roundedV = String(round(value! * 100000) / 100000)
            OutputLabel.text! = roundedV
            if (Secondv == "0")
            {
                OutputLabel.text! = "Error"
            }
        }
        let Sep = OutputLabel.text!.components(separatedBy: ".")
        if (Sep.last == "0")
               {
                   OutputLabel.text! = Sep[0]
               }
        //OutputLabel.text! = ""
    }
    
    @IBAction func button7(_ sender: UIButton) {
        OutputLabel.text = OutputLabel.text! + String(7)
        if (Secondx == true)
        {
            addToSecondv(value: "7")
        }
        else{
            addToFirstv(value: "7")
        }
    }
    @IBAction func button8(_ sender: UIButton) {
        OutputLabel.text = OutputLabel.text! + String(8)
        if (Secondx == true)
        {
            addToSecondv(value: "8")
        }
        else{
            addToFirstv(value: "8")
        }
    }
    @IBAction func button9(_ sender: UIButton) {
        OutputLabel.text = OutputLabel.text! + String(9)
        if (Secondx == true)
        {
            addToSecondv(value: "9")
        }
        else{
            addToFirstv(value: "9")
        }
    }
    @IBAction func button4(_ sender: UIButton) {
        OutputLabel.text = OutputLabel.text! + String(4)
        if (Secondx == true)
        {
            addToSecondv(value: "4")
        }
        else{
            addToFirstv(value: "4")
        }
    }
    @IBAction func button5(_ sender: UIButton) {
        OutputLabel.text = OutputLabel.text! + String(5)
        if (Secondx == true)
        {
            addToSecondv(value: "5")
        }
        else{
            addToFirstv(value: "5")
        }
    }
    @IBAction func button6(_ sender: UIButton) {
        OutputLabel.text = OutputLabel.text! + String(6)
        if (Secondx == true)
        {
            addToSecondv(value: "6")
        }
        else{
            addToFirstv(value: "6")
        }
    }
    @IBAction func button1(_ sender: UIButton) {
        OutputLabel.text = OutputLabel.text! + String(1)
        if (Secondx == true)
        {
            addToSecondv(value: "1")
        }
        else{
            addToFirstv(value: "1")
        }
    }
    @IBAction func button2(_ sender: UIButton) {
        OutputLabel.text = OutputLabel.text! + String(2)
        if (Secondx == true)
        {
            addToSecondv(value: "2")
        }
        else{
            addToFirstv(value: "2")
        }
    }
    @IBAction func button3(_ sender: UIButton) {
        OutputLabel.text = OutputLabel.text! + String(3)
        if (Secondx == true)
        {
            addToSecondv(value: "3")
        }
        else{
            addToFirstv(value: "3")
        }
    }
    @IBAction func button0(_ sender: UIButton) {
        OutputLabel.text = OutputLabel.text! + String(0)
        if (Secondx == true)
        {
            addToSecondv(value: "0")
        }
        else{
            addToFirstv(value: "0")
        }
    }
}
