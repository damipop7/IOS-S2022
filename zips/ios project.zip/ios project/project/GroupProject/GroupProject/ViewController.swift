//
//  ViewController.swift
//  GroupProject
//
//  Created by Student on 4/7/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

