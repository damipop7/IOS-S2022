//
//  ViewController.swift
//  Popoola_DiceGame
//
//  Created by Student on 4/7/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var Player1: UITextField!
    @IBOutlet weak var Player2: UITextField!
    @IBAction func PlayGame(_ sender: Any) {
        var P1 = Player1.text
        var P2 = Player2.text
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "ResultSegue"{
            let destination = segue.destination as! ResultViewController
            destination.p1 = Player1.text!
            destination.p2 = Player2.text!
            
        }
    }

}
