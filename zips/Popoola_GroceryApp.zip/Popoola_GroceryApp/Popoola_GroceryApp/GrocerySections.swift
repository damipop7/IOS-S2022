//
//  GrocerySections.swift
//  Popoola_GroceryApp
//
//  Created by Student on 4/7/22.
//

import Foundation
import UIKit
struct GrocerySections {
    var section : String
    var items_Array : [GroceryItem]
    
}

struct GroceryItem {
    var itemName : String
    var itemImage : UIImage
    var itemInfo : String
}


let Details1 =  GrocerySections(section: "Meat", items_Array:[
        GroceryItem(itemName: "Chicken", itemImage: UIImage.init(named: "chicken-1")!, itemInfo: "The chicken is a domesticated subspecies of the red junglefowl, with attributes of wild species such as grey and ceylon junglefowl that are originally from Southeastern Asia."),
        GroceryItem(itemName: "Turkey", itemImage: UIImage.init(named: "turkey-1")!, itemInfo: "The turkey is a large bird in the genus Meleagris, native to North America.Turkey meat, commonly referred to as just turkey, is the meat from turkeys, typically domesticated turkeys but also wild turkeys."),
        GroceryItem(itemName: "Beef", itemImage:UIImage.init(named: "beef-1")! , itemInfo: "Beef is the culinary name for meat from cattle. In prehistoric times, humans hunted aurochs and later domesticated them."),
        GroceryItem(itemName: "Pork", itemImage: UIImage.init(named: "Pork")!, itemInfo: "Pork is the culinary name for the meat of the domestic pig. It is the most commonly consumed meat worldwide, with evidence of pig husbandry dating back to 5000 BC."),
        GroceryItem(itemName: "Lamb", itemImage: UIImage.init(named: "lamb")!, itemInfo: "Lamb, hogget, and mutton, generically sheep meat, are the meat of domestic sheep, Ovis aries. A sheep in its first year is a lamb and its meat is also lamb.")
])
    
let Details2 =  GrocerySections(section: "Fish", items_Array:[
        GroceryItem(itemName: "Crabs", itemImage: UIImage.init(named: "crabs")!, itemInfo: "Crabs are decapod crustaceans of the infraorder Brachyura, which typically have a very short projecting tail, usually hidden entirely under the thorax. They live in all the world's oceans, in fresh water, and on land, are generally covered with a thick exoskeleton, and have a single pair of pincers."),
        GroceryItem(itemName: "Sardines", itemImage: UIImage.init(named: "sardines")!, itemInfo: "Sardines are common names for various small, oily forage fish in the herring family Clupeidae."),
        GroceryItem(itemName: "Salmon", itemImage: UIImage.init(named: "salmon")!, itemInfo: "Salmon is a common food fish classified as an oily fish with a rich content of protein and omega-3 fatty acids."),
        GroceryItem(itemName: "Mackerel", itemImage: UIImage.init(named: "mackerel")!, itemInfo: "Mackerel is a common name applied to a number of different species of pelagic fish, mostly from the family Scombridae. They are found in both temperate and tropical seas."),
        GroceryItem(itemName: "Lobster", itemImage: UIImage.init(named: "lobster")!, itemInfo: "Lobsters are a family of large marine crustaceans. Lobsters have long bodies with muscular tails, and live in crevices or burrows on the sea floor. Three of their five pairs of legs have claws, including the first pair, which are usually much larger than the others.")
])

let Details3 =  GrocerySections(section: "Vegetables", items_Array:[
    GroceryItem(itemName: "Coleslaw", itemImage: UIImage.init(named: "coleslaw")!, itemInfo: "Coleslaw, also known as cole slaw, or simply as slaw, is a side dish consisting primarily of finely shredded raw cabbage with a salad dressing or condiment, commonly either vinaigrette or mayonnaise. "),
    GroceryItem(itemName: "Spinach", itemImage: UIImage.init(named: "spinach")!, itemInfo: "Spinach is a leafy green flowering plant native to central and western Asia. It is of the order Caryophyllales, family Amaranthaceae, subfamily Chenopodioideae. Its leaves are a common edible vegetable consumed either fresh,"),
    GroceryItem(itemName: "Lettuce", itemImage: UIImage.init(named: "lettuce")!, itemInfo: "Lettuce (Lactuca sativa) is an annual plant of the daisy family, Asteraceae. It is most often grown as a leaf vegetable, but sometimes for its stem and seeds. Lettuce is most often used for salads"),
    GroceryItem(itemName: "Carrot", itemImage: UIImage.init(named: "carrot")!, itemInfo: "The carrot is a root vegetable, typically orange in color, though purple, black, red, white, and yellow cultivars exist, all of which are domesticated forms of the wild carrot."),
    GroceryItem(itemName: "Broccoli", itemImage: UIImage.init(named: "Broccoli")!, itemInfo: "Broccoli is an edible green plant in the cabbage family whose large flowering head, stalk and small associated leaves are eaten as a vegetable. ")
])

let Details4 =  GrocerySections(section: "Snacks", items_Array:[
      GroceryItem(itemName: "oreos", itemImage: UIImage.init(named: "oroes")!, itemInfo: "Oreos is a brand of creme-filled sandwich cookie consisting of two (usually chocolate) wafers with a sweet crème filling."),
      GroceryItem(itemName: "Milk", itemImage: UIImage.init(named: "milk")!, itemInfo: "Milk is a nutrient-rich liquid food produced by the mammary glands of mammals. It is the primary source of nutrition for young mammals before they are able to digest solid food."),
      GroceryItem(itemName: "biscuit", itemImage: UIImage.init(named: "biscuit")!, itemInfo: "A biscuit is a flour-based baked and shaped food product. In most countries biscuits are typically hard, flat, and unleavened. They are usually sweet and may be made with sugar, chocolate, icing, jam, ginger, or cinnamon."),
      GroceryItem(itemName: "apple", itemImage: UIImage.init(named: "apple")!, itemInfo: "An apple is an edible fruit produced by an apple tree. Apple trees are cultivated worldwide and are the most widely grown species in the genus Malus. The tree originated in Central Asia, where its wild ancestor, Malus sieversii, is still found today."),
      GroceryItem(itemName: "bread", itemImage: UIImage.init(named: "bread")!, itemInfo: "Bread is a staple food prepared from a dough of flour and water, usually by baking. Throughout recorded history and around the world, it has been an important part of many cultures' diet.")
])

let Details5 = GrocerySections(section: "Beverages", items_Array: [
        GroceryItem(itemName: "Tea", itemImage: UIImage.init(named: "tea")!, itemInfo: "Tea is an aromatic beverage prepared by pouring hot or boiling water over cured or fresh leaves of Camellia sinensis, an evergreen shrub native to China, India and other East Asian countries."),
        GroceryItem(itemName: "Hot Chocolate", itemImage: UIImage.init(named: "hot chocolate")!, itemInfo: "Hot chocolate, also known as hot cocoa or drinking chocolate, is heated chocolate milk. Hot chocolate made with melted chocolate is sometimes called drinking chocolate, characterized by less sweetness and a thicker consistency."),
        GroceryItem(itemName: "Sprite", itemImage: UIImage.init(named: "sprite")!, itemInfo: "Sprite is a colorless, lemon and lime-flavored soft drink created by The Coca-Cola Company. It was first developed in West Germany in 1959 as Fanta Klare Zitrone and was introduced in the United States under the current brand name Sprite in 1961 as a competitor to 7 Up"),
        GroceryItem(itemName: "water", itemImage: UIImage.init(named: "water")!, itemInfo: "Water is an inorganic, transparent, tasteless, odorless, and nearly colorless chemical substance, which is the main constituent of Earth's hydrosphere and the fluids of all known living organisms. It is vital for all known forms of life, even though it provides no calories or organic nutrients."),
        GroceryItem(itemName: "juice", itemImage: UIImage.init(named: "juice")!, itemInfo: "Juice is a drink made from the extraction or pressing of the natural liquid contained in fruit and vegetables. It can also refer to liquids that are flavored with concentrate or other biological food sources, such as meat or seafood, such as clam juice.")
        ])
    
let grocerySections = [Details1, Details2, Details3, Details4, Details5]

