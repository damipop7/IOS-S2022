//
//  ItemInfoViewController.swift
//  Popoola_GroceryApp
//
//  Created by Student on 4/7/22.
//

import UIKit

class ItemInfoViewController: UIViewController {

    var info = GroceryItem(itemName: "", itemImage:(UIImage.init(named: "chicken") ?? UIImage.init(named: "notfound"))!, itemInfo: "z")
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        itemInfoOutlet.text = info.itemInfo
        itemImageViewOutlet.image = info.itemImage
        itemInfoOutlet.isHidden = true
        self.title = info.itemName
    }
    
    @IBOutlet weak var itemImageViewOutlet: UIImageView!
    @IBAction func showItemInfoAction(_ sender: Any) {
        itemInfoOutlet.isHidden = false
        itemInfoOutlet.text = info.itemInfo
    }
    @IBOutlet weak var itemInfoOutlet: UITextView!
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
